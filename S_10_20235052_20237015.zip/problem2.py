#Malak Moustafa Abdel Maboud Salem 20237015
#Abdelrahman Mahmoud Fathy Ibrahim 20235052

#we first begin by defining that is used/called whenever we need to check if a number is a binary 
def binary(num):
    for bit in num:
        if bit != '0' and bit != '1':
            return False
    return True # if every digit/bit in a number is either 1 or 0 
# A Function to be used whenever the user wants to get the one's complement of a binary number
#the one's complement is obtained by replacing every 1 with 0 and vice versa
def ones_complement(num1):
    return ''.join('0' if bit == '1' else '1' for bit in num1)
# A Function to be used whenever the user wants to get the two's complement of a binary number
#the two's complement is obtained by first, getting the one's complement and then adding 1 to the result
def twos_complement(num1):
    inverted_number = ones_complement(num1)
    carry = 1
    result = ''
    for bit in inverted_number[::-1]:
        if bit == '0' and carry == 1:
            result = '1' + result
            carry = 0
        elif bit == '1' and carry == 1:
            result = '0' + result
        else:
            result = bit + result
    return result
# A Function to be used whenever the user wants to add two binary numbers
def addition(num1, num2):
    max_len = max(len(num1), len(num2))#this function is used to detemine the maximum length between num1 and num2
    #the following functions are used to ensure that the two numbers are of the same length by padding them with leading zeros
    num1 = num1.zfill(max_len)
    num2 = num2.zfill(max_len)
    carry = 0
    result = ''
    for i in range(len(num1) - 1, -1, -1):
        bit_sum = int(num1[i]) + int(num2[i]) + carry
        result = str(bit_sum % 2) + result
        carry = bit_sum // 2
    return result
# A Function to be used whenever the user wants to add two binary numbers
#if we want to subtract num1 from num2, we first get the two's complement for num2 then add num1 with the complemented version of num2
def subtraction(num1, num2):
    max_len = max(len(num1), len(num2))#this function is used to detemine the maximum length between num1 and num2
    #the following functions are used to ensure that the two numbers are of the same length by padding them with leading zeros
    num1 = num1.zfill(max_len)
    num2 = num2.zfill(max_len)
    
    num2 = twos_complement(num2)
    result = addition(num1, num2)
    return result.zfill(max_len)  # Pad the result if needed
#A function to check if the number is positive or negative
def positive(num):
    if num[0] == '0':
        return True  # The number is positive
    else:
        return False  # The number is not positive
while True:
    print("\nBinary Calculator: \nA) Insert new numbers \nB) Exit")
    choice = input("Please select an option (A || B): ")
    #if the user chooses A then they will be asked to insert a valid binary number(named num1)
    if choice.upper() == 'A':
        num1 = input("Please insert a binary number: ")
        while not binary(num1):
            print("Please insert a valid binary number.")
            num1 = input("Please insert a number in binary: ")
        #if the user inserted a valid binary number then Menu2 will be displayed  
        print("A) Compute one's complement")
        print("B) Compute two's complement")
        print("C) Addition")
        print("D) Subtraction")
        operation = input("Please select an operation from above: ")
        #if the user chooses A then they will get the one's complement
        if operation.upper() == 'A':  
            print("The one's complement of", num1, "is", ones_complement(num1))
            
        #if the user chooses B then they will get the two's complement
        elif operation.upper() == 'B':  
              print("The two's complement of", num1, "is", twos_complement(num1))
            
        #if the user chooses C then they will be asked to insert another vaild binary number(named num2) to perform addition 
        elif operation.upper() == 'C':
            num2 = input("Please insert another binary number: ")
            while not binary(num2):
                print("Please insert a valid binary number.")
                num2 = input("Please insert the second number: ")
            print("The sum of", num1, "and", num2, "is", addition(num1, num2))
        #if the user chooses D then they will be asked to insert another vaild binary number(named num2) to perform subtraction
        elif operation.upper() == 'D':
            num2 = input("Please insert the second number: ")
            while not binary(num2):
                print("Please insert a valid binary number.")
                num2 = input("Please insert the second number: ")
            result = subtraction(num1, num2)
            if positive(result):
                print("The difference between" ,num1,"and",num2,"is", result)
            else :
                print("This results in a negative number")
        else :
           print("Please select a valid choice") 
    elif choice.upper() == 'B':
        print("Exiting Binary Calculator.")
        break
    
    else:
        print("Please select a valid choice (A || B).")