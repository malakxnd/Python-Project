# ABDELRAHMAN MAHMOUD FATHY IBRAHIM (20235052)
# MALAK MOUSTAFA ABDEL MABOUD SALEM (20237015)

# THERE ARE TOO MANY WAYS FOR CONVERTING FROM ALL THE TYPES BUT WE CHOSE SOME VARIOUS WAYS TO DO IT

# Function to check if a number is valid in a given base
def valid(number, base):
# SETTING THE NUMBER SET OF CHOSEN VALUES ONLY
    digits = set('0123456789ABCDEF'[:base])
# RETURNING THE RESULT
# SETTING THE INPUT OF THE SET AS UPPERCASE 
    return all(digit.upper() in digits for digit in number)

# CONVERTING FROM DECIMAL TO BINARY 
def dec_bin(dec_num):
# SETTING THE VALUE OF 0 AS ZERO BECAUSE IT HAS NO VALUE 
    if dec_num == 0:
        return '0'
#  SEETING THE RESULT OF BINARY AS STRING IN ORDER TO NOT INTERFERE WITH INTS
    binary = ''
# SETTING THE CONDITION FOR THE FUNCTION TO WORK "THE NUMBER SHOULD BE GREATER THAN ZERO"
    while dec_num > 0:
# GETTING THE VALUE OF THE REMAINDER (2 BECAUSE OF BIN HAS ONLY 2 DIGITS)
        remainder = dec_num % 2
# CALCULATING THE VALUE OF BINARY
# SETTING THE VALUE OF THE REMAINDER AS STRING AND ADDING THE VALUE OF BINARY TO IT
        binary = str(remainder) + binary
# HAVING A FLOOR DIVISION FOR THE DECIMAL VALUE THE USER WILL ADD
        dec_num //= 2
# GETTING THE FINAL RESULT OF CONVERTING FROM DECIMAL TO BINARY
    return binary

# CONVERTING FROM DECIMAL TO OCTAL
def dec_oct(dec_num):
# SETTING THE VALUE OF 0 AS ZERO BECAUSE IT HAS NO VALUE 
    if dec_num == 0:
        return '0'
#  SEETING THE RESULT OF OCTAL AS STRING IN ORDER TO NOT INTERFERE WITH INTS
    octal = ''
# SETTING THE CONDITION FOR THE FUNCTION TO WORK "THE NUMBER SHOULD BE GREATER THAN ZERO"
    while dec_num > 0:
# GETTING THE VALUE OF THE REMAINDER (8 BECAUSE OF BIN HAS ONLY 8 DIGITS)
        remainder = dec_num % 8
# SETTING THE VALUE OF THE REMAINDER AS STRING AND ADDING THE VALUE OF OCTAL TO IT
        octal = str(remainder) + octal
# HAVING A FLOOR DIVISION FOR THE DECIMAL VALUE THE USER WILL ADD
        dec_num //= 8
# GETTING THE FINAL RESULT OF CONVERTING FROM DECIMAL TO OCTAL
    return octal

# CONVERTING FROM DECIMAL TO HEXADECIMAL
def dec_hex(dec_num):
# SETTING THE VALUE OF 0 AS ZERO BECAUSE IT HAS NO VALUE 
    if dec_num == 0:
        return '0'
#  SEETING THE RESULT OF HEXADECIMAL AS STRING IN ORDER TO NOT INTERFERE WITH INTS
    hexadecimal = ''
# SETTING THE INPUT THAT ONLY ALLOWED TO TAKE FROM THE USER
    hex_chars = '0123456789ABCDEF'
# SETTING THE CONDITION FOR THE FUNCTION TO WORK "THE NUMBER SHOULD BE GREATER THAN ZERO"
    while dec_num > 0:
# GETTING THE VALUE OF THE REMAINDER (16 BECAUSE OF BIN HAS ONLY 16 DIGITS)
        remainder = dec_num % 16
# CONNECTING THE REMAINDER WITH THE HEXADECIMAL CHARACTERS
        hexadecimal = hex_chars[remainder] + hexadecimal
# HAVING A FLOOR DIVISION FOR THE DECIMAL VALUE THE USER WILL ADD
        dec_num //= 16
# GETTING THE FINAL RESULT OF CONVERTING FROM DECIMAL TO HEXADECIMAL
    return hexadecimal

# CONVERTING FROM BINARY TO DECIMAL
def bin_dec(bin_num):
    decimal = 0
# CALCULATING THE POWER TO THE MOST SIGNIFICANT BIT
    power = len(bin_num) - 1
# NOW CALCULATING THE RESULT FOR EACH DIGIT
    for digit in bin_num:
# TAIKING EVERY DIGIT AND MULTIPLY IT BY 2 TO THE POWER OF ITS POSITION (CONVERTING BINARY RULE)
        decimal += int(digit) * (2 ** power)
# DECREAMENT THE POWER TO -1 FOR THE NEXT ITERATION
        power -= 1
# GETTING THE VALUE AS DECIMAL VALUE
    return decimal

# BINARY TO OCTAL
def bin_oct(bin_num):
# CALLING THE bin_dec FUNCTION TO CONVERT THE NUMBER THAT HAS BEEN ENTERED TO DECIMAL
    decimal = bin_dec(bin_num)
# CALLING THE dec_oct FUNCTION TO CONVERT THE DECIMAL VALUE THAT HAS BEEN CONVERTED IN THE LAST LINE
    octal = dec_oct(decimal)
# GETTING THE VALUE AS OCTAL VALUE
    return octal

# BINARY TO HEXADECIMAL
def bin_hex(bin_num):
# CALLING THE bin_dec FUNCTION TO CONVERT THE NUMBER THAT HAS BEEN ENTERED TO DECIMAL
    decimal = bin_dec(bin_num)
# CALLING THE dec_oct FUNCTION TO CONVERT THE DECIMAL VALUE THAT HAS BEEN CONVERTED IN THE LAST LINE
    hexadecimal = dec_hex(decimal)
# GETTING THE VALUE AS HEXADECIMAL VALUE
    return hexadecimal

# Function to check if a number is a valid hexadecimal
def val_hex(hex_num):
    digits = '0123456789ABCDEF'
# SETTING THE USER INPUT AS UPPERCASE
    hex_num = hex_num.upper()
# SETTING ALL THE CHARS IN (digits)-set AS HEXADECIMAL VALUES
    return all(digit in digits for digit in hex_num)

# USING A DICTIONARY TO SET THE VALUES OF HEXADECIMAL TO ITS BINARY VALUES
def hex_dig_bin(hex_dig):
    hex_bin = {
        '0': '0000', '1': '0001', '2': '0010', '3': '0011', '4': '0100', '5': '0101', '6': '0110', '7': '0111', '8': '1000', '9': '1001', 'A': '1010', 'B': '1011', 'C': '1100', 'D': '1101', 'E': '1110', 'F': '1111'
    }
# LOOKING IN THE DICTIONARY FOR THE SETTED VALUE AND GETTING IT AS A RESULT
    return hex_bin[hex_dig]

# HEXADECIMAL TO BIANRY
def hex_bin(hex_num):
# CHECKING IF THE INPUT IS ALREADY IN THE SET OF THE VALUES THAT HAS BEEN SETTED (val_hex) DIGIT BY DIGIT
    if not val_hex(hex_num):
        return "Invalid hexadecimal number"
    else:
# SETTING THE VALUE AS A STRING
        binary = ''
# SETTING EVERY INPUT THE USER ENTERED AS UPPERCASE
        hex_num = hex_num.upper()
# SETTING A CONDITION FOR THE VALID DIGITS IN THE FUNCTION (hex_num)
        for digit in hex_num:
# CALLING (hex_dig-bin) TO CONVERT EVERY DIGIT TO ITS BINARY VALUE
            binary += hex_dig_bin(digit)
# GETTING THE RESULT AS A BINARY VALUE
        return binary

# HEXADECIMAL TO OCTAL
def hex_oct(hex_num):
# CHECKING IF THE INPUT IS ALREADY IN THE SET OF THE VALUES THAT HAS BEEN SETTED (val_hex) DIGIT BY DIGIT
    if not val_hex(hex_num):
        return "Invalid hexadecimal number"

    binary = hex_bin(hex_num)
    octal = ''
    binary_length = len(binary)

# Padding to ensure binary length is divisible by 3 for octal conversion
    if binary_length % 3 != 0:
        padding = 3 - (binary_length % 3)
        binary = '0' * padding + binary

    for i in range(0, len(binary), 3):
        binary_chunk = binary[i:i + 3]
        octal += str(int(binary_chunk, 2))
    return octal

# HEXADECIMAL TO DECIMAL
def hex_dec(hex_num):
# CHECKING IF THE INPUT IS ALREADY IN THE SET OF THE VALUES THAT HAS BEEN SETTED (val_hex) DIGIT BY DIGIT
    if not val_hex(hex_num):
        return "Invalid hexadecimal number"
# SETTING DECIMAL TO 0 AS INTITIAL VALUE
    decimal = 0
    # SETTING THE INPUT OF THE USER FOR HEX DIGITS AS UPPERCASE
    hex_num = hex_num.upper()
# SEETING THE DIGITS OF THE HEXADECIMAL INPUTS THAT IS ONLY ALLOWED
    hex_chars = '0123456789ABCDEF'
    for digit in hex_num:
        decimal = decimal * 16 + hex_chars.index(digit)
    return decimal

# OCTAL TO BINARY
def oct_bin(oct_num):
# CHECKING IF THE INPUT IS ALREADY IN THE SET OF THE VALUES THAT HAS BEEN SETTED (val_hex) DIGIT BY DIGIT
    if not valid(oct_num, 8):
        return "Invalid octal number"
# SORTING THE VALUE OF BINARY AS A STRING
    binary = ''
    for digit in oct_num:
        decimal = int(digit)
        binary += format(decimal, '03b')  # '03' ensures 3 digits with leading zeros for each octal digit
    return binary


# Function to convert octal to decimal
def oct_dec(oct_num):
    if not valid(oct_num, 8):
        return "Invalid octal number"

    decimal = 0
    power = len(oct_num) - 1
    for digit in oct_num:
        decimal += int(digit) * (8 ** power)
        power -= 1
    return decimal

# Function to convert octal to hexadecimal
def oct_hex(oct_num):
    if not valid(oct_num, 8):
        return "Invalid octal number"
# CONVERTING THE INPUT TO A DECIMAL FIRST
# ALLOWING FOR DECIMAL VAR TO TAKE ONLY THE DIGITS OF OCTAL
    decimal = oct_dec(oct_num)
# CONVERTING THE DECIMAL TO HEXA AS (dec_hex) FUNCTION
    hexadecimal = ''
    hex_chars = '0123456789ABCDEF'
    while decimal > 0:
        remainder = decimal % 16
        hexadecimal = hex_chars[remainder] + hexadecimal
        decimal //= 16
    return hexadecimal
# STARTING THE PROGRAM WHILE THE CODE IS RUNNING WELL
while True:
# PRINTIN THE FIRST MENU
    print("numbering system converter")
    print("A) insert a new number")
    print("B) Exit program")
# TAKIN THE CHOISE FROM THE USER TO START THE PROGRAM OR STOP
    choice = input("Please select an option: ")
# STARTING THE PROGRAM CONDITION
    if choice.upper() == 'A':
# TAKIN A VALUE FROM THE USER TO CONVERT 
        number = input("Please insert a number: ")
# SHOWING UP THE SECOND MENU
        print("Please select the base you want to convert the number from:")
        print("A) Decimal")
        print("B) Binary")
        print("C) Octal")
        print("D) Hexadecimal")
# TAKING THE USER CHOICE AND SETTING IT AS AN UPPERCASE
        base_1 = input("Your choice: ").upper()
# CHECKING IF THE USER HAS CHOSE A VALID CHOICE OR NOT
        if base_1 not in ['A', 'B', 'C', 'D']:
# PRINTING AN ERROR MESSAGE IF THE USER ENTERED AN INVALID VALUE
            print("Please select a valid choice.\n")
# THE CONDITIONS FOR CHOOSING THE VALID VALUES  
        else:
# SHOWING UP THE THRID MENU
            print("Please select the base you want to convert the number to:")
            print("A) Decimal")
            print("B) Binary")
            print("C) Octal")
            print("D) Hexadecimal")
# TAKING THE INPUT FROM THE USER AS AN UPPERCASE
            base_2 = input("Your choice: ").upper()
# CHECKING IF THE USER HAS CHOSE A VALID CHOICE OR NOT
            if base_2 not in ['A', 'B', 'C', 'D']:
# PRINTING AN ERROR MESSAGE IF THE USER ENTERED AN INVALID VALUE
                print("Please select a valid choice.\n")
            else:
                bases = {'A': 10, 'B': 2, 'C': 8, 'D': 16}
                converted_number = None  # Initialize converted_number

                if not valid(number.upper(), bases[base_1]):
                    print("Please insert a valid number for the selected base.")
                else:
# STARTING CONVERTING BASED ON CHOSEN BASES
                    # CONVERTING FROM DECIMAL
                    if base_1 == 'A':
# CONVERTING FROM DECIMAL TO BINARY
                        if base_2 == 'B':
                            converted_number = dec_bin(int(number))
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM DECIMAL TO OCTAL
                        elif base_2 == 'C':
                            converted_number = dec_oct(int(number))
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM DECIMAL TO HEXADECIMAL
                        elif base_2 == 'D':
                            converted_number = dec_hex(int(number))
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
                        else:
                            print("please enter a valid choice")
# CONVERTING FROM BINARY
                    elif base_1 == 'B':
# CONVERTING FROM BINARY TO DECIMAL
                        if base_2 == 'A':
                            converted_number = bin_dec(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM BINARY TO OCTAL 
                        elif base_2 == 'C':
                            converted_number = bin_oct(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM BINARY TO HEXADECIMAL
                        elif base_2 == 'D':
                            converted_number = bin_hex(number)
                            print(f"The{number} in {base_2.upper()} is: {converted_number}")
                        else:
                            print("please enter a valid choice")
# CONVERTING FROM OCTAL
                    elif base_1 == 'C':
# CONVERTING FROM OCTAL TO DECIMAL
                        if base_2 == 'A':
                            converted_number = oct_dec(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM OCTAL TO BINARY
                        elif base_2 == 'B':
                            converted_number = oct_bin(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM OCTAL TO HEXADECIMAL
                        elif base_2 == 'D':
                            converted_number = oct_hex(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
                        else:
                            print("please enter a valid choice")
# CONVERTING FROM HEXADECIMAL
                    elif base_1 == 'D':
# CONVERTING FROM HEXADECIMAL TO DECIMAL
                        if base_2 == 'A':
                            converted_number = hex_dec(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM HEXADECIMAL TO BINARY
                        elif base_2 == 'B':
                            converted_number = hex_bin(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
# CONVERTING FROM HEXADECIMAL TO OCTAL
                        elif base_2 == 'C':
                            converted_number = hex_oct(number)
                            print(f"The {number} in {base_2.upper()} is: {converted_number}")
                        else:
                            print("please enter a valid choice")
# EXITING THE PROGRAM FOR CHOOSING TO EXIT IN THE FIRST MENU
    elif choice.upper() == 'B':
                        print("Exiting the program. Thank you!")
                        break
# ERROR MESSAGE
    else:
        print("Please select a valid choice.")